const popup = document.getElementById('popup');

    function openPopup() {
      popup.style.display = 'flex';
    }

    function closePopup() {
      popup.style.display = 'none';
    }

    function submitLogin(event) {
      event.preventDefault();
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      console.log("Login details:", { email, password });

      // Add your real login logic here...

      alert('Logged in as: ' + email);
      closePopup();
    }

    const signupPopup = document.getElementById('signupPopup');

    function openSignup() {
      signupPopup.style.display = 'flex';
    }

    function closeSignup() {
      signupPopup.style.display = 'none';
    }

    function submitSignup(event) {
      event.preventDefault();

      const name = document.getElementById('name').value;
      const email = document.getElementById('signupEmail').value;
      const password = document.getElementById('signupPassword').value;

      console.log("Signup Info:", { name, email, password });

      // Add signup logic here...

      alert('Account created for: ' + name);
      closeSignup();
    }
// const links = document.querySelectorAll("a.click");
// Select all anchor tags with class "click"

  // Smooth scroll on tab click
  document.querySelectorAll('.click').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const targetId = this.getAttribute('href').substring(1);
      const targetEl = document.getElementById(targetId);

      if (targetEl) {
        targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
 // scroll to navigation bar
 function submitLogin(event) {
  event.preventDefault();

  // Fetching login credentials
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  // Simulate login (you should replace this with actual auth logic)
  if (email && password) {
    // Close the popup
    closePopup();

    // Delay for a smooth transition
    setTimeout(() => {
      // Scroll to the navigation tab section
      document.querySelector(".tab-menu").scrollIntoView({ behavior: "smooth" });
    }, 300); // slight delay so the popup finishes closing
  } else {
    alert("Please fill in all fields!");
  }
}


function closePopup() {
  document.getElementById("popup").style.display = "none";
}

// sign in hide
function submitSignup(event) {
  event.preventDefault();

  // Fetching sign-up form values
  const name = document.getElementById("name").value;
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;

  // Simulate account creation (replace this with real sign-up logic)
  if (name && email && password) {
    // Close the sign-up popup
    closeSignup();

    // Delay scroll to allow UI to update
    setTimeout(() => {
      // Scroll to the navigation tab section
      document.querySelector(".tab-menu").scrollIntoView({ behavior: "smooth" });
    }, 300);
  } else {
    alert("Please fill in all fields!");
  }
}

function closeSignup() {
  document.getElementById("signupPopup").style.display = "none";
}

// setTimeout(() => {
//   alert("Welcome aboard!");
//   document.querySelector(".tab-menu").scrollIntoView({ behavior: "smooth" });
// }, 300);


  // profile dropdown
  function toggleDropdown(event) {
    event.stopPropagation();
    document.getElementById("profileDropdown").classList.toggle("show");
  }

  // Close dropdown when clicking outside
  window.addEventListener("click", () => {
    document.getElementById("profileDropdown").classList.remove("show");
  });
document.addEventListener("DOMContentLoaded", () => {

  // TO-DO INTERACTION (Optional extension, add elements if needed)
  document.getElementById("add-task-btn").addEventListener("click", function () {
    const taskInput = document.getElementById("task-input");
    const taskText = taskInput.value.trim();

    if (taskText !== "") {
      const listItem = document.createElement("li");
      listItem.innerHTML = `
        <label class="task-item">
          <input type="checkbox" class="task-checkbox" />
          <span>${taskText}</span>
        </label>
      `;
      document.getElementById("todo-list").appendChild(listItem);
      taskInput.value = "";
    }
  });
  // HOMEWORK UPLOAD BUTTON
  const uploadBtn = document.querySelector(".upload-btn");
  if (uploadBtn) {
    uploadBtn.addEventListener("click", () => {
      alert("Homework uploaded successfully!");
    });
  }

  // DOUBT INPUT HANDLER
  const doubtInput = document.querySelector(".doubt-input");
  const doubtSearchIcon = document.querySelector(".search-icon");
  const solutionBox = document.querySelector(".solution-box");

// voice to text
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (!SpeechRecognition) {
  alert("Speech Recognition not supported in this browser");
} else {
  const recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  function startVoiceToText(inputId) {
    const inputField = document.getElementById(inputId);
    inputField.placeholder = "Listening... 🎙️";
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      inputField.value = transcript;
      inputField.placeholder = "Ask any doubt ?";
    };

    recognition.onerror = (event) => {
      inputField.placeholder = `Error: ${event.error}`;
    };
  }
}
// For search icon
  if (doubtSearchIcon && doubtInput && solutionBox) {
    doubtSearchIcon.addEventListener("click", () => {
      const question = doubtInput.value.trim();
      if (question) {
        const para = document.createElement("p");
        para.textContent = `Q: ${question} → A: Your answer will appear soon.`;
        solutionBox.appendChild(para);
        doubtInput.value = "";
      }
    });
  }

  // PRACTICE QUESTION ATTEMPT MARKING
  const practiceBox = document.querySelector(".practice-box ul");
  if (practiceBox) {
    practiceBox.addEventListener("click", (e) => {
      if (e.target.tagName === "LI") {
        e.target.style.textDecoration = "line-through";
        e.target.style.color = "gray";
      }
    });
  }
  //
  const startTestBtn = document.getElementById('startTestBtn');
  const attemptsBadge = document.getElementById('attemptsBadge');

  // Extract number from badge text
  function getRemainingAttempts() {
    const text = attemptsBadge.textContent;
    const match = text.match(/\d+/);
    return match ? parseInt(match[0]) : 0;
  }

  // Update badge text
  function updateAttemptsDisplay(count) {
    attemptsBadge.textContent = `${count} Attempts left`;
  }

  // Handle click
  startTestBtn.addEventListener('click', () => {
    let attempts = getRemainingAttempts();

    if (attempts > 0) {
      attempts--;
      updateAttemptsDisplay(attempts);

      if (attempts === 0) {
        startTestBtn.disabled = true;
        startTestBtn.style.opacity = 0.5;
        startTestBtn.textContent = 'No Attempts Left';
      }
    }
  });

  // end of this 
  document.getElementById('startTestBtn').addEventListener('click', function () {
    // Show message
    const msg = document.getElementById('examMessage');
    msg.textContent = '✅ Your exam has started';
    msg.style.display = 'block';

    // Show the Weekly Exam section
    document.getElementById('weeklyExamSection').style.display = 'block';

    // Optionally, scroll to the exam section
    document.getElementById('weeklyExamSection').scrollIntoView({ behavior: 'smooth' });
  });
  // document.querySelector('.info-row').style.display = 'none';

  // WEEKLY TEST - Submit Button
  const submitTestBtn = document.querySelector(".submit-btn");
  const questionBox = document.querySelector(".question-box");

  if (submitTestBtn && questionBox) {
    submitTestBtn.addEventListener("click", () => {
      alert("Test submitted successfully!");
      questionBox.innerHTML += `<p><b>✔ Your answers have been saved.</b></p>`;
    });
  }

});

// for timer and exam auto submitted
let countdown; // To store the interval
const examDuration = 30 * 60; // 30 minutes in seconds

document.getElementById('startTestBtn').addEventListener('click', function () {
  // Show message
  const msg = document.getElementById('examMessage');
  msg.textContent = '✅ Your exam has started';
  msg.style.display = 'block';

  // Show exam section
  document.getElementById('weeklyExamSection').style.display = 'block';

  // Show timer
  const timerDisplay = document.getElementById('timer');
  timerDisplay.style.display = 'block';

  // Hide the test info section
  document.querySelectorAll('.info-row')[0].style.display = 'none';

  // Start the timer
  let timeLeft = examDuration;

  function updateTimer() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    timerDisplay.textContent = `Time Left: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

    if (timeLeft <= 0) {
      clearInterval(countdown);
      autoSubmitTest();
    } else {
      timeLeft--;
    }
  }

  updateTimer(); // Initial call
  countdown = setInterval(updateTimer, 1000);

  function stopTimer() {
    clearInterval(countdown);
  }
  // document.getElementById('examMessage').style.display = 'block';
  //   document.getElementById('timer').style.display = 'none';
});
// For leave button

  const leaveBtn = document.getElementById('leaveBtn');
  const leavePopup = document.getElementById('leavePopup');
  const confirmLeave = document.getElementById('confirmLeave');
  const cancelLeave = document.getElementById('cancelLeave');
  const weeklyExamSection = document.getElementById('weeklyExamSection');

  leaveBtn.addEventListener('click', () => {
    leavePopup.style.display = 'flex';
  });

  cancelLeave.addEventListener('click', () => {
    leavePopup.style.display = 'none';
  });

  confirmLeave.addEventListener('click', () => {
    leavePopup.style.display = 'none';
    weeklyExamSection.style.display = 'none';
    alert('You have left the test.');
  });
  
// end leave button

function autoSubmitTest() {
  document.getElementById('examMessage').textContent = '⏰ Time up! Your test has been auto-submitted.';
  document.getElementById('timer').style.color = 'gray';

  // Optionally disable all buttons
  const buttons = document.querySelectorAll('.option-btn, .submit-btn');
  buttons.forEach(btn => btn.disabled = true);
}